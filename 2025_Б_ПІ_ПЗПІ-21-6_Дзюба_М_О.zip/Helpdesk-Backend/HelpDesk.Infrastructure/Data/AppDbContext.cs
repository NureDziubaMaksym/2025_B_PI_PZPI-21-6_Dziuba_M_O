﻿using HelpDesk.Infrastructure.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

namespace HelpDesk.Infrastructure.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options) { }

        public DbSet<User> Users { get; set; }
        public DbSet<Ticket> Tickets { get; set; }
        public DbSet<TicketClassification> TicketClassifications { get; set; }
        public DbSet<Department> Departments { get; set; }
        public DbSet<TicketRouting> TicketRouting { get; set; }
        public DbSet<DepartmentRouting> DepartmentRoutings { get; set; }
        public DbSet<Company> Companies { get; set; }
        public DbSet<Report> Reports { get; set; }
        public DbSet<Feedback> Feedback { get; set; }
        public DbSet<AssignedRouting> AssignedRoutings { get; set; }
        public DbSet<HeatMapMetric> HeatMapMetrics { get; set; }
        public DbSet<UserCompany> UserCompanies { get; set; }
        public DbSet<Incident> Incidents { get; set; }

        protected override void OnModelCreating(ModelBuilder b)
        {

            b.Entity<TicketClassification>()
             .HasOne(tc => tc.Ticket)
             .WithMany(t => t.TicketClassifications)
             .HasForeignKey(tc => tc.TicketId);

            b.Entity<DepartmentRouting>()
             .ToTable("DepartmentRouting")
             .HasKey(dr => new { dr.DepartmentId, dr.TicketRoutingId });

            b.Entity<DepartmentRouting>()
             .HasOne(dr => dr.Department)
             .WithMany(d => d.DepartmentRoutings)
             .HasForeignKey(dr => dr.DepartmentId)
             .OnDelete(DeleteBehavior.Cascade);

            b.Entity<DepartmentRouting>()
             .HasOne(dr => dr.TicketRouting)
             .WithMany(tr => tr.DepartmentRoutings)
             .HasForeignKey(dr => dr.TicketRoutingId)
             .OnDelete(DeleteBehavior.Cascade);

            b.Entity<User>()
             .HasOne(u => u.Department)
             .WithMany(d => d.Users)
             .HasForeignKey(u => u.DepartmentId)
             .OnDelete(DeleteBehavior.SetNull)
             .IsRequired(false);

            b.Entity<AssignedRouting>(ar =>
            {
                ar.ToTable("AssignedRouting");
                ar.HasKey(x => x.Id);

                ar.HasOne(x => x.TicketRouting)
                  .WithMany(tr => tr.AssignedRoutings)
                  .HasForeignKey(x => x.TicketRoutingId)
                  .OnDelete(DeleteBehavior.Cascade);

                ar.HasOne(x => x.User)
                  .WithMany(u => u.AssignedRoutings)
                  .HasForeignKey(x => x.UserId)
                  .OnDelete(DeleteBehavior.Cascade);

                ar.Property(x => x.AssignedAt)
                  .IsRequired();
            });

            b.Entity<Department>()
             .HasOne(d => d.Company)
             .WithMany(c => c.Departments)
             .HasForeignKey(d => d.CompanyId);

            b.Entity<Feedback>()
             .HasOne(f => f.Ticket)
             .WithMany(t => t.Feedback)
             .HasForeignKey(f => f.TicketId);

            b.Entity<Feedback>()
             .HasOne(f => f.User)
             .WithMany(u => u.Feedback)
             .HasForeignKey(f => f.UserId);

            b.Entity<Report>()
             .HasOne(r => r.User)
             .WithMany(u => u.Reports)
             .HasForeignKey(r => r.UserId)
             .OnDelete(DeleteBehavior.Restrict);

            b.Entity<HeatMapMetric>()
             .HasIndex(h => new { h.EntityType, h.EntityId, h.MetricsDateTime })
             .IsUnique();

            b.Entity<Ticket>()
             .Property(t => t.Files)
             .HasColumnType("text[]")
             .HasDefaultValueSql("ARRAY[]::text[]")
             .IsRequired();

            b.Entity<UserCompany>()
            .HasKey(uc => new { uc.UserId, uc.CompanyId });

            b.Entity<UserCompany>()
                .HasOne(uc => uc.User)
                .WithMany(u => u.UserCompanies)
                .HasForeignKey(uc => uc.UserId);

            b.Entity<UserCompany>()
                .HasOne(uc => uc.Company)
                .WithMany(c => c.UserCompanies)
                .HasForeignKey(uc => uc.CompanyId);

            b.Entity<Incident>()
             .HasOne(i => i.User)
             .WithMany(u => u.Incidents)
             .HasForeignKey(i => i.UserId)
             .OnDelete(DeleteBehavior.Restrict);

            b.Entity<Incident>()
             .HasOne(i => i.Ticket)
             .WithMany(t => t.Incidents)
             .HasForeignKey(i => i.TicketId)
             .OnDelete(DeleteBehavior.Cascade);
        }
    }

}
