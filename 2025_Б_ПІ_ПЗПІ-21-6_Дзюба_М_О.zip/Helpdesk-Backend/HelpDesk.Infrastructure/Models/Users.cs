﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;

namespace HelpDesk.Infrastructure.Models
{
    public class User
    {
        public int Id { get; set; }
        public string Email { get; set; }
        public string PasswordHash { get; set; }
        public UserRole Role { get; set; }
        public string Name { get; set; }
        public string Phone { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }

        public int? DepartmentId { get; set; }
        public Department Department { get; set; }


        public ICollection<AssignedRouting> AssignedRoutings { get; set; }
        public ICollection<Feedback> Feedback { get; set; }
        public ICollection<Report> Reports { get; set; } = new List<Report>();
        public ICollection<UserCompany> UserCompanies { get; set; } = new List<UserCompany>();
        public ICollection<Incident> Incidents { get; set; } = new List<Incident>();
    }

    public enum UserRole
    {
        Client = 1,
        Specialist = 2,
        Admin = 3
    }
}
