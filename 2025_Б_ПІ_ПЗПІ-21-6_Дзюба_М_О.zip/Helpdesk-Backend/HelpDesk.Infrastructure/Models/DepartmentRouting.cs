﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDesk.Infrastructure.Models
{
    public class DepartmentRouting
    {
        public int DepartmentId { get; set; }
        public Department Department { get; set; }

        public int TicketRoutingId { get; set; }
        public TicketRouting TicketRouting { get; set; }
    }
}
