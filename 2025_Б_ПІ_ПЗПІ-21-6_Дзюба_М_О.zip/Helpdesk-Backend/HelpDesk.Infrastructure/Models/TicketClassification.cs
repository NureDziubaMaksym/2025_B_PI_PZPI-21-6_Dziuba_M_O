﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDesk.Infrastructure.Models
{
    public class TicketClassification
    {
        public int Id { get; set; }
        public int TicketId { get; set; }
        public string Category { get; set; }
        public string Version { get; set; }
        public decimal Confidence { get; set; }
        public DateTime ClassifiedAt { get; set; }

        public Ticket Ticket { get; set; }
    }
}
