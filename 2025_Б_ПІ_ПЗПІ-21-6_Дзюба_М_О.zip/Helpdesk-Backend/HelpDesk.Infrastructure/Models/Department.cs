﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace HelpDesk.Infrastructure.Models
{
    public class Department
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int CompanyId { get; set; }
        public Company Company { get; set; }

        public ICollection<DepartmentRouting> DepartmentRoutings { get; set; } = new List<DepartmentRouting>();

        public ICollection<User> Users { get; set; } = new List<User>();
        public ICollection<TicketRouting> TicketRoutings { get; set; }
    }
}
