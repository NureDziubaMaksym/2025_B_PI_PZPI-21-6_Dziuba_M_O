﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDesk.Infrastructure.Models
{
    public class Ticket
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string[] Files { get; set; } = Array.Empty<string>();
        public TicketPriority Priority { get; set; }
        public TicketStatus Status { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }

        public ICollection<TicketClassification> TicketClassifications { get; set; }
        public ICollection<TicketRouting> TicketRouting { get; set; }
        public ICollection<Feedback> Feedback { get; set; }
        public ICollection<Incident> Incidents { get; set; } = new List<Incident>();
    }

    public enum TicketPriority
    {
        Low,
        Medium,
        High
    }

    public enum TicketStatus
    {
        Open,
        InProgress,
        Resolved,
        Closed
    }
}
