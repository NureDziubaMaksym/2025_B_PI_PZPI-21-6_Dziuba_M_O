﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HelpDesk.Infrastructure.Models
{
    public class HeatMapMetric
    {
        [Key]
        public int Id { get; set; }
        
        [Required]
        [MaxLength(20)]
        public string EntityType { get; set; }

        [Required]
        public int EntityId { get; set; }

        [Required]
        public DateTime MetricsDateTime { get; set; }

        public int OpenCount { get; set; }

        public int ClosedCount { get; set; }

        public double AvgResolution { get; set; }

        public int SlaViolations { get; set; }
    }
}
