﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDesk.Infrastructure.Models
{
    public class TicketRouting
    {
        public int Id { get; set; }
        public int TicketId { get; set; }
        public DateTime RoutedAt { get; set; }
        public RoutingStatus Status { get; set; }

        public Ticket Ticket { get; set; }
        public ICollection<DepartmentRouting> DepartmentRoutings { get; set; }
        public ICollection<AssignedRouting> AssignedRoutings { get; set; }
        
    }

    public enum RoutingStatus
    {
        Pending,
        Processed,
        Escalated
    }
}
