﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace HelpDesk.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class AddHeatMapMetrics : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "HeatMapMetrics",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    EntityType = table.Column<string>(type: "character varying(20)", maxLength: 20, nullable: false),
                    EntityId = table.Column<int>(type: "integer", nullable: false),
                    MetricsDateTime = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    OpenCount = table.Column<int>(type: "integer", nullable: false),
                    ClosedCount = table.Column<int>(type: "integer", nullable: false),
                    AvgResolution = table.Column<double>(type: "double precision", nullable: false),
                    SlaViolations = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HeatMapMetrics", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_HeatMapMetrics_EntityType_EntityId_MetricsDateTime",
                table: "HeatMapMetrics",
                columns: new[] { "EntityType", "EntityId", "MetricsDateTime" },
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "HeatMapMetrics");
        }
    }
}
