﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace HelpDesk.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class AddAssignedRoutingTable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_TicketRouting_Users_AssignedToUserId",
                table: "TicketRouting");

            migrationBuilder.DropIndex(
                name: "IX_TicketRouting_AssignedToUserId",
                table: "TicketRouting");

            migrationBuilder.CreateTable(
                name: "AssignedRouting",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    TicketRoutingId = table.Column<int>(type: "integer", nullable: false),
                    UserId = table.Column<int>(type: "integer", nullable: false),
                    AssignedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AssignedRouting", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AssignedRouting_TicketRouting_TicketRoutingId",
                        column: x => x.TicketRoutingId,
                        principalTable: "TicketRouting",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_AssignedRouting_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_AssignedRouting_TicketRoutingId",
                table: "AssignedRouting",
                column: "TicketRoutingId");

            migrationBuilder.CreateIndex(
                name: "IX_AssignedRouting_UserId",
                table: "AssignedRouting",
                column: "UserId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AssignedRouting");

            migrationBuilder.CreateIndex(
                name: "IX_TicketRouting_AssignedToUserId",
                table: "TicketRouting",
                column: "AssignedToUserId");

            migrationBuilder.AddForeignKey(
                name: "FK_TicketRouting_Users_AssignedToUserId",
                table: "TicketRouting",
                column: "AssignedToUserId",
                principalTable: "Users",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
