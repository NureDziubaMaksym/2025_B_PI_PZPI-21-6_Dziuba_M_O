﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HelpDesk.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class DepartmentNullable : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_TicketRouting_DepartmentId",
                table: "TicketRouting",
                column: "DepartmentId");

            migrationBuilder.AddForeignKey(
                name: "FK_TicketRouting_Departments_DepartmentId",
                table: "TicketRouting",
                column: "DepartmentId",
                principalTable: "Departments",
                principalColumn: "Id",
                onDelete: ReferentialAction.SetNull);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_TicketRouting_Departments_DepartmentId",
                table: "TicketRouting");

            migrationBuilder.DropIndex(
                name: "IX_TicketRouting_DepartmentId",
                table: "TicketRouting");
        }
    }
}
