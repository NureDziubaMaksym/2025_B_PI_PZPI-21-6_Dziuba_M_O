﻿using AutoMapper;
using HelpDesk.Core.DtoModels;
using HelpDesk.Core.Interfaces;
using HelpDesk.Infrastructure.Models;
using Microsoft.AspNetCore.Mvc;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace HelpDesk.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserCompaniesController : ControllerBase
    {
        private readonly IUserCompanyRepository _repo;
        private readonly IMapper _mapper;

        public UserCompaniesController(IUserCompanyRepository repo, IMapper mapper)
        {
            _repo = repo;
            _mapper = mapper;
        }

        // GET api/UserCompanies/user/5
        [HttpGet("user/{userId}")]
        public async Task<ActionResult<IEnumerable<CompanyDto>>> GetByUser(int userId)
        {
            var companies = await _repo.GetCompaniesByUser(userId);
            var dto = _mapper.Map<IEnumerable<CompanyDto>>(companies);
            return Ok(dto);
        }
    }
}
