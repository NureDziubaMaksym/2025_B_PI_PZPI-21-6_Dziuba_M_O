﻿using AutoMapper;
using HelpDesk.Core.DtoModels;
using HelpDesk.Core.Interfaces;
using HelpDesk.Infrastructure.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HelpDesk.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly IUserRepository _users;
        private readonly IMapper _mapper;

        public UsersController(IUserRepository users, IMapper mapper)
        {
            _users = users;
            _mapper = mapper;
        }

        // GET /api/users
        [HttpGet]
        public async Task<ActionResult<IEnumerable<UserDto>>> GetAllUsers()
        {
            var list = await _users.GetAllUsers();
            var dto = _mapper.Map<IEnumerable<UserDto>>(list);

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            return Ok(dto);
        }

        // GET /api/users/{id}
        [HttpGet("{id:int}")]
        public async Task<ActionResult<UserDto>> GetUserById(int id)
        {
            var user = await _users.GetUserById(id);

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (user == null)
                return NotFound();
            var dto = _mapper.Map<UserDto>(user);
            return Ok(dto);
        }

        // POST /api/users
        [HttpPost]
        public async Task<ActionResult<UserDto>> CreateUser([FromBody] UserCreateDto dto)
        {
            if (dto == null)
                return BadRequest("User data is required.");

            var user = _mapper.Map<User>(dto);

            var created = await _users.CreateUser(user, dto.Password);

            var result = _mapper.Map<UserDto>(created);

            return CreatedAtAction(nameof(GetUserById),new { id = result.Id }, result);
        }

        // PUT /api/users/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateUser(int id, [FromBody] UserUpdateDto dto)
        {
            if (dto == null)
                return BadRequest("User data is required.");

            var existing = await _users.GetUserById(id);
            if (existing == null)
                return NotFound($"User with id={id} not found.");

            _mapper.Map(dto, existing);

            await _users.UpdateUser(existing);

            return NoContent();
        }

        // DELETE /api/users/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteUser(int id)
        {
            var exists = await _users.GetUserById(id);
            if (exists == null)
                return NotFound();

            await _users.DeleteUser(id);
            return NoContent();
        }

        // GET /api/users/{email}
        [HttpGet("by-email/{email}")]
        public async Task<ActionResult<UserDto>> GetUserByEmail(string email)
        {
            var user = await _users.GetUserByEmail(email);

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (user == null)
                return NotFound();
            var dto = _mapper.Map<UserDto>(user);
            return Ok(dto);
        }

        [HttpGet("no-department")]
        public async Task<ActionResult<IEnumerable<UserDto>>> GetUsersWithoutDepartment()
        {
            var list = await _users.GetUsersWithoutDepartmentAsync();
            var dto = _mapper.Map<IEnumerable<UserDto>>(list);
            return Ok(dto);
        }

        // PATCH /api/users/{userId}/department/{departmentId}
        [HttpPatch("{userId:int}/department/{departmentId:int}")]
        public async Task<IActionResult> AssignDepartment(int userId, int departmentId)
        {
            await _users.AssignToDepartmentAsync(userId, departmentId);
            return NoContent();
        }

        [HttpPatch("{userId:int}/department/remove")]
        public async Task<IActionResult> RemoveDepartment(int userId)
        {
            var existing = await _users.GetUserById(userId);
            if (existing == null)
                return NotFound($"User with id={userId} not found.");

            await _users.UnassignDepartmentAsync(userId);
            return NoContent();
        }
    }
}
