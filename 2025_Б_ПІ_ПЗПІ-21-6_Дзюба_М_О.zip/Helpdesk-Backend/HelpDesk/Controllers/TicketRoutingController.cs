﻿using AutoMapper;
using HelpDesk.Core.DtoModels;
using HelpDesk.Core.Interfaces;
using HelpDesk.Infrastructure.Models;
using Microsoft.AspNetCore.Mvc;

namespace HelpDesk.Controllers
{
    [Route("api/ticket-routing")]
    [ApiController]
    public class TicketRoutingController : ControllerBase
    {
        private readonly ITicketRoutingRepository _repo;
        private readonly IMapper _mapper;
        private readonly ITicketRoutingService _service;
        private readonly IDepartmentRepository _deptRepo;
        private readonly IUserRepository _userRepo;

        public TicketRoutingController(ITicketRoutingRepository repo, IMapper mapper, ITicketRoutingService service, IUserRepository userRepo, IDepartmentRepository deptRepo)
        {
            _repo = repo;
            _mapper = mapper;
            _service = service;
            _deptRepo = deptRepo;
            _userRepo = userRepo;
        }

        // GET /api/ticket-routing
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TicketRoutingDto>>> GetAll()
        {
            var list = await _repo.GetAllTicketRoutings();
            var dtos = _mapper.Map<IEnumerable<TicketRoutingDto>>(list);
            return Ok(dtos);
        }

        // GET /api/ticket-routing/{ticketId}
        [HttpGet("{ticketId:int}")]
        public async Task<ActionResult<TicketRoutingDto>> GetByTicket(int ticketId)
        {
            var routing = await _repo.GetRoutingByTicketId(ticketId);
            if (routing == null) return NotFound();
            return Ok(_mapper.Map<TicketRoutingDto>(routing));
        }

        // GET /api/ticket-routing/user/{userId}
        [HttpGet("user/{userId:int}")]
        public async Task<ActionResult<IEnumerable<TicketRoutingDto>>> GetByUser(int userId)
        {
            var routings = await _repo.GetRoutingsByUserId(userId);
            if (!routings.Any()) return NotFound();
            var dtos = _mapper.Map<IEnumerable<TicketRoutingDto>>(routings);
            return Ok(dtos);
        }

        // POST /api/ticket-routing
        [HttpPost]
        public async Task<ActionResult<TicketRoutingDto>> Create([FromBody] TicketRoutingCreateDto createDto)
        {
            if (createDto == null) return BadRequest();

            var entity = _mapper.Map<TicketRouting>(createDto);
            var created = await _repo.CreateTicketRouting(entity);

            var resultDto = _mapper.Map<TicketRoutingDto>(created);
            return CreatedAtAction(nameof(GetByTicket),
                                   new { ticketId = resultDto.TicketId },
                                   resultDto);
        }

        // PUT /api/ticket-routing/{id}
        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, [FromBody] TicketRoutingCreateDto updateDto)
        {
            if (updateDto == null) return BadRequest();

            var existing = await _repo.GetRoutingByTicketId(id);
            if (existing == null) return NotFound();

            _mapper.Map(updateDto, existing);
            await _repo.UpdateTicketRouting(existing);

            return NoContent();
        }

        // DELETE /api/ticket-routing/{id}
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var exists = await _repo.GetRoutingByTicketId(id);
            if (exists == null) return NotFound();
            await _repo.DeleteTicketRouting(id);
            return NoContent();
        }

        // PATCH /api/ticket-routing/{id}/status/{newStatus}
        [HttpPatch("{id:int}/status/{newStatus}")]
        public async Task<IActionResult> ChangeStatus(int id, string newStatus)
        {
            var exists = await _repo.GetRoutingByTicketId(id);
            if (exists == null) return NotFound();

            await _repo.ChangeRoutingStatus(id, (int)Enum.Parse<RoutingStatus>(newStatus));
            return NoContent();
        }

        // PATCH /api/ticket-routing/{id}/user/{newUserId}
        [HttpPatch("{id:int}/user/{newUserId:int}")]
        public async Task<IActionResult> ChangeUser(int id, int newUserId)
        {
            var existing = await _repo.GetRoutingByTicketId(id);
            if (existing == null)
                return NotFound();

            await _repo.ChangeUserForTicket(id, newUserId);
            return NoContent();
        }

        [HttpPost("classify")]
        public ActionResult<ClassificationResultDto> Classify([FromBody] TicketTextDto dto)
        {
            var result = _service.Classify(dto);
            return Ok(result);
        }

        // POST api/ticket-routing/route
        [HttpPost("route")]
        public async Task<ActionResult<RoutingDecisionDto>> Route([FromBody] TicketTextDto dto)
        {
            var decision = await _service.RouteAsync(dto);
            return Ok(decision);
        }

        [HttpPatch("{ticketId:int}/assign-department/{departmentId:int}")]
        public async Task<IActionResult> AssignToDepartment(int ticketId, int departmentId)
        {
            // 1) Убедимся, что департамент существует
            var dept = await _deptRepo.GetDepartmentById(departmentId);
            if (dept == null)
                return NotFound($"Department with id={departmentId} not found.");

            // 2) Убедимся, что существует запись маршрутизации тикета  
            //    (если хотите автоматически создавать маршрут, то проверку убрать)
            var routing = await _repo.GetRoutingByTicketId(ticketId);
            if (routing == null)
                return NotFound($"Routing for ticket {ticketId} not found.");

            // 3) Делаем привязку
            await _repo.AssignToDepartment(ticketId, departmentId);
            return NoContent();
        }

        /// <summary>
        /// Привязать тикет к специалисту
        /// </summary>
        [HttpPatch("{ticketId:int}/assign-user/{userId:int}")]
        public async Task<IActionResult> AssignToUser(int ticketId, int userId)
        {
            // 1) Убедимся, что пользователь существует
            var user = await _userRepo.GetUserById(userId);
            if (user == null)
                return NotFound($"User with id={userId} not found.");

            // 2) Убедимся, что маршрут тикета уже создан
            var routing = await _repo.GetRoutingByTicketId(ticketId);
            if (routing == null)
                return NotFound($"Routing for ticket {ticketId} not found.");

            // 3) Делаем привязку
            await _repo.AssignToUser(ticketId, userId);
            return NoContent();
        }
    }
}
