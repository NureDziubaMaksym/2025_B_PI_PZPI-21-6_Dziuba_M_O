﻿using AutoMapper;
using HelpDesk.Core.DtoModels;
using HelpDesk.Core.Interfaces;
using HelpDesk.Infrastructure.Models;
using Microsoft.AspNetCore.Mvc;

namespace HelpDesk.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TicketClassificationsController : ControllerBase
    {
        private readonly ITicketClassificationRepository _repo;
        private readonly IMapper _mapper;

        public TicketClassificationsController(ITicketClassificationRepository repo, IMapper mapper)
        {
            _repo = repo;
            _mapper = mapper;
        }

        // GET: api/ticketclassifications
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TicketClassificationDto>>> GetAll()
        {
            var list = await _repo.GetAllClassifications();
            var dto = _mapper.Map<IEnumerable<TicketClassificationDto>>(list);
            return Ok(dto);
        }

        // GET: api/ticketclassifications/{ticketId}
        [HttpGet("{ticketId}")]
        public async Task<ActionResult<TicketClassificationDto>> GetByTicket(int ticketId)
        {
            var cls = await _repo.GetClassificationByTicketId(ticketId);
            if (cls == null)
                return NotFound();

            var dto = _mapper.Map<TicketClassificationDto>(cls);
            return Ok(dto);
        }

        // POST: api/ticketclassifications
        [HttpPost]
        public async Task<ActionResult<TicketClassificationDto>> Create([FromBody] TicketClassificationCreateDto createDto)
        {
            if (createDto == null) return BadRequest();

            var entity = _mapper.Map<TicketClassification>(createDto);
            var created = await _repo.CreateTicketClassification(entity);

            var resultDto = _mapper.Map<TicketClassificationDto>(created);
            return CreatedAtAction(nameof(GetByTicket),
                                   new { ticketId = resultDto.TicketId },
                                   resultDto);
        }

        // PUT: api/ticketclassifications/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] TicketClassificationUpdateDto updateDto)
        {
            if (updateDto == null || updateDto.Id != id)
                return BadRequest();

            var exists = await _repo.GetClassificationByTicketId(updateDto.Id);
            if (exists == null) return NotFound();

            _mapper.Map(updateDto, exists);
            await _repo.UpdateTicketClassification(exists);
            return NoContent();
        }

        // DELETE: api/ticketclassifications/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var entity = await _repo.GetClassificationByTicketId(id);
            if (entity == null || entity.Id != id)
                return NotFound();

            await _repo.DeleteTicketClassification(id);
            return NoContent();
        }
    }
}
