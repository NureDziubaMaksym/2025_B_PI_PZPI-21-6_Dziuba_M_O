﻿using AutoMapper;
using HelpDesk.Core.DtoModels;
using HelpDesk.Core.Interfaces;
using HelpDesk.Infrastructure.Models;
using Microsoft.AspNetCore.Mvc;

namespace HelpDesk.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CompaniesController : ControllerBase
    {
        private readonly ICompanyRepository _repo;
        private readonly IMapper _mapper;
        private readonly IDepartmentRepository _deptRepo;

        public CompaniesController(ICompanyRepository repo, IMapper mapper, IDepartmentRepository deptRepo)
        {
            _repo = repo;
            _mapper = mapper;
            _deptRepo = deptRepo;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<CompanyDto>>> GetCompanies()
        {
            var list = await _repo.GetCompanies();
            var dto = _mapper.Map<IEnumerable<CompanyDto>>(list);
            return Ok(dto);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<CompanyDto>> GetCompanyById(int id)
        {
            var company = await _repo.GetCompanyById(id);
            if (company == null) return NotFound();
            var dto = _mapper.Map<CompanyDto>(company);
            return Ok(dto);
        }

        [HttpPost]
        public async Task<ActionResult<CompanyDto>> CreateCompany([FromBody] CompanyCreateDto createDto)
        {
            if (createDto == null) return BadRequest();

            var entity = _mapper.Map<Company>(createDto);
            var created = await _repo.CreateCompany(entity);

            var resultDto = _mapper.Map<CompanyDto>(created);
            return CreatedAtAction(nameof(GetCompanyById),
                                   new { id = resultDto.Id },
                                   resultDto);
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> UpdateCompany(int id, [FromBody] CompanyCreateDto updateDto)
        {
            if (updateDto == null) return BadRequest();

            var existing = await _repo.GetCompanyById(id);
            if (existing == null) return NotFound();

            _mapper.Map(updateDto, existing);
            await _repo.UpdateCompany(existing);

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCompany(int id)
        {
            var exists = await _repo.GetCompanyById(id);
            if (exists == null)
                return NotFound();

            await _repo.DeleteCompany(id);
            return NoContent();
        }

        [HttpGet("{companyId}/departments")]
        public async Task<ActionResult<IEnumerable<DepartmentDto>>> GetDepartments(int companyId)
        {
            var list = await _deptRepo.GetDepartmentsByCompany(companyId);
            return Ok(list);
        }

    }
}
