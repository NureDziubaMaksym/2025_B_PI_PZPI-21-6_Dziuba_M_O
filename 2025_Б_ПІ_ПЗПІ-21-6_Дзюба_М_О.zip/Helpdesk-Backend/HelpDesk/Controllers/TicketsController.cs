﻿using Microsoft.AspNetCore.Mvc;
using HelpDesk.Infrastructure.Models;
using HelpDesk.Core.Interfaces;
using System.Threading.Tasks;
using System.Collections.Generic;
using Microsoft.AspNetCore.Authorization;
using AutoMapper;
using HelpDesk.Core.DtoModels;

namespace HelpDesk.Controllers
{
    //[Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class TicketsController : Controller
    {
        private readonly ITicketRepository _ticketRepository;
        private readonly IMapper _mapper;
        public TicketsController(ITicketRepository ticketRepository, IMapper mapper)
        {
            _ticketRepository = ticketRepository;
            _mapper = mapper;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<TicketDto>>> GetAllTickets()
        {
            var tickets = await _ticketRepository.GetAllTickets();
            var dtos = _mapper.Map<IEnumerable<TicketDto>>(tickets);
            return Ok(dtos);
        }

        // GET /api/tickets/{id}
        [HttpGet("{id}")]
        public async Task<ActionResult<TicketDto>> GetTicketById(int id)
        {
            var ticket = await _ticketRepository.GetTicketById(id);

            if (ticket == null)
            {
                return NotFound();
            }

            return Ok(ticket);
        }

        [HttpPost]
        public async Task<ActionResult<TicketDto>> CreateTicket([FromBody] TicketCreateDto dto)
        {
            if (dto == null) return BadRequest();

            var entity = _mapper.Map<Ticket>(dto);
            var created = await _ticketRepository.CreateTicket(entity);

            var result = _mapper.Map<TicketDto>(created);
            return CreatedAtAction(nameof(GetTicketById), new { id = result.Id }, result);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateTicket(int id, [FromBody] TicketUpdateDto dto)
        {
            if (dto == null) return BadRequest();

            var existing = await _ticketRepository.GetTicketById(id);
            if (existing == null) return NotFound();

            _mapper.Map(dto, existing);
            await _ticketRepository.UpdateTicket(existing);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTicket(int id)
        {
            var existingTicket = await _ticketRepository.GetTicketById(id);

            if (existingTicket == null)
            {
                return NotFound();
            }

            await _ticketRepository.DeleteTicket(id);
            return NoContent();
        }

        // GET /api/tickets/user/{userId}
        [HttpGet("user/{userId}")]
        public async Task<ActionResult<IEnumerable<TicketDto>>> GetTicketsForUser(int userId)
        {

            var tickets = await _ticketRepository.GetTicketsByUserId(userId);
            var dto = _mapper.Map<IEnumerable<TicketDto>>(tickets);

            return Ok(dto);
        }

        [HttpPatch("{id:int}/priority/{newPriority}")]
        public async Task<IActionResult> UpdatePriority(int id, string newPriority)
        {
            if (!Enum.TryParse<TicketPriority>(newPriority, true, out var priority))
                return BadRequest($"Invalid priority value: {newPriority}");

            var ticket = await _ticketRepository.GetTicketById(id);
            if (ticket == null) return NotFound();

            ticket.Priority = priority;
            ticket.UpdatedAt = DateTime.UtcNow;
            await _ticketRepository.UpdateTicket(ticket);

            return NoContent();
        }

        /// PATCH /api/tickets/{id}/status/{newStatus}
        [HttpPatch("{id:int}/status/{newStatus}")]
        public async Task<IActionResult> UpdateStatus(int id, string newStatus)
        {
            if (!Enum.TryParse<TicketStatus>(newStatus, true, out var status))
                return BadRequest($"Invalid status value: {newStatus}");

            var ticket = await _ticketRepository.GetTicketById(id);
            if (ticket == null) return NotFound();

            ticket.Status = status;
            ticket.UpdatedAt = DateTime.UtcNow;
            await _ticketRepository.UpdateTicket(ticket);

            return NoContent();
        }
    }
}
