﻿using AutoMapper;
using HelpDesk.Core.DtoModels;
using HelpDesk.Core.Interfaces;
using HelpDesk.Infrastructure.Models;
using Microsoft.AspNetCore.Mvc;

namespace HelpDesk.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DepartmentsController : ControllerBase
    {
        private readonly IDepartmentRepository _repo;
        private readonly IMapper _mapper;
        private readonly ITicketRoutingRepository _routingRepo;

        public DepartmentsController(IDepartmentRepository repo, IMapper mapper, ITicketRoutingRepository routingRepo)
        {
            _repo = repo;
            _mapper = mapper;
            _routingRepo = routingRepo;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<DepartmentDto>>> GetAll()
        {
            var depts = await _repo.GetAllDepartments();
            var dtos = _mapper.Map<IEnumerable<DepartmentDto>>(depts);
            return Ok(dtos);
        }

        [HttpGet("{id:int}")]
        public async Task<ActionResult<DepartmentDto>> GetById(int id)
        {
            var dept = await _repo.GetDepartmentById(id);
            if (dept == null) return NotFound();
            return Ok(_mapper.Map<DepartmentDto>(dept));
        }

        [HttpPost]
        public async Task<ActionResult<DepartmentDto>> Create([FromBody] DepartmentCreateDto createDto)
        {
            if (createDto == null) return BadRequest();
            var entity = _mapper.Map<Department>(createDto);
            var created = await _repo.CreateDepartment(entity);
            var dto = _mapper.Map<DepartmentDto>(created);
            return CreatedAtAction(nameof(GetById), new { id = dto.Id }, dto);
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, [FromBody] DepartmentCreateDto updateDto)
        {
            if (updateDto == null) return BadRequest();
            var exists = await _repo.GetDepartmentById(id);
            if (exists == null) return NotFound();
            _mapper.Map(updateDto, exists);
            await _repo.UpdateDepartment(exists);
            return NoContent();
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var exists = await _repo.GetDepartmentById(id);
            if (exists == null) return NotFound();
            await _repo.DeleteDepartment(id);
            return NoContent();
        }

        [HttpGet("company/{companyId:int}")]
        public async Task<ActionResult<IEnumerable<DepartmentDto>>> GetByCompany(int companyId)
        {
            var list = await _repo.GetDepartmentsByCompany(companyId);
            if (!list.Any()) return NotFound();
            var dtos = _mapper.Map<IEnumerable<DepartmentDto>>(list);
            return Ok(dtos);
        }

        [HttpGet("{id:int}/users")]
        public async Task<ActionResult<IEnumerable<UserDto>>> GetUsersInDepartment(int id)
        {
            var dept = await _repo.GetDepartmentById(id);
            if (dept == null) return NotFound();

            var users = await _repo.GetUsersByDepartment(id);
            var dtos = _mapper.Map<IEnumerable<UserDto>>(users);
            return Ok(dtos);
        }

        [HttpGet("{id:int}/tickets")]
        public async Task<ActionResult<IEnumerable<TicketDto>>> GetTicketsForDepartment(int id)
        {
            var dept = await _repo.GetDepartmentById(id);
            if (dept == null) return NotFound($"Department {id} not found.");

            var routings = await _routingRepo.GetRoutingsByDepartmentAsync(id);

            var tickets = routings
                .Select(r => r.Ticket)
                .Where(t => t != null);

            var dtos = _mapper.Map<IEnumerable<TicketDto>>(tickets);
            return Ok(dtos);
        }
    }
}
