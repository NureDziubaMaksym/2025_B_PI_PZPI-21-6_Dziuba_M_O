﻿using AutoMapper;
using HelpDesk.Core.DtoModels;
using HelpDesk.Core.Interfaces;
using HelpDesk.Infrastructure.Models;
using Microsoft.AspNetCore.Mvc;

namespace HelpDesk.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class IncidentsController : ControllerBase
    {
        private readonly IIncidentRepository _repo;
        private readonly IMapper _mapper;

        public IncidentsController(IIncidentRepository repo, IMapper mapper)
        {
            _repo = repo;
            _mapper = mapper;
        }

        // GET /api/incidents
        [HttpGet]
        public async Task<ActionResult<IEnumerable<IncidentDto>>> GetAll()
        {
            var list = await _repo.GetAllIncidentsAsync();
            return Ok(_mapper.Map<IEnumerable<IncidentDto>>(list));
        }

        // GET /api/incidents/{id}
        [HttpGet("{id:int}")]
        public async Task<ActionResult<IncidentDto>> GetById(int id)
        {
            var inc = await _repo.GetIncidentByIdAsync(id);
            if (inc == null) return NotFound();
            return Ok(_mapper.Map<IncidentDto>(inc));
        }

        // GET /api/incidents/ticket/{ticketId}
        [HttpGet("ticket/{ticketId:int}")]
        public async Task<ActionResult<IEnumerable<IncidentDto>>> GetByTicket(int ticketId)
        {
            var list = await _repo.GetIncidentsByTicketIdAsync(ticketId);
            return Ok(_mapper.Map<IEnumerable<IncidentDto>>(list));
        }

        // POST /api/incidents
        [HttpPost]
        public async Task<ActionResult<IncidentDto>> Create([FromBody] IncidentCreateDto dto)
        {
            var entity = _mapper.Map<Incident>(dto);
            var created = await _repo.CreateIncidentAsync(entity);
            var outDto = _mapper.Map<IncidentDto>(created);
            return CreatedAtAction(nameof(GetById), new { id = outDto.Id }, outDto);
        }

        // PUT /api/incidents/{id}
        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, [FromBody] IncidentUpdateDto dto)
        {
            var existing = await _repo.GetIncidentByIdAsync(id);
            if (existing == null) return NotFound();

            _mapper.Map(dto, existing);
            await _repo.UpdateIncidentAsync(existing);
            return NoContent();
        }

        // DELETE /api/incidents/{id}
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var existing = await _repo.GetIncidentByIdAsync(id);
            if (existing == null) return NotFound();

            await _repo.DeleteIncidentAsync(id);
            return NoContent();
        }
    }
}
