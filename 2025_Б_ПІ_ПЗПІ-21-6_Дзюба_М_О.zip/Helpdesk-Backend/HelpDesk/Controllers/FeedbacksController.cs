﻿using AutoMapper;
using HelpDesk.Core.DtoModels;
using HelpDesk.Core.Interfaces;
using HelpDesk.Infrastructure.Models;
using Microsoft.AspNetCore.Mvc;

namespace HelpDesk.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class FeedbacksController : ControllerBase
    {
        private readonly IFeedbackRepository _repo;
        private readonly IMapper _mapper;

        public FeedbacksController(IFeedbackRepository repo, IMapper mapper)
        {
            _repo = repo;
            _mapper = mapper;
        }

        // GET /api/feedbacks
        [HttpGet]
        public async Task<ActionResult<IEnumerable<FeedbackDto>>> GetAll()
        {
            var list = await _repo.GetAllFeedbacks();
            return Ok(_mapper.Map<IEnumerable<FeedbackDto>>(list));
        }

        // GET /api/feedbacks/{id}
        [HttpGet("{id:int}")]
        public async Task<ActionResult<FeedbackDto>> GetById(int id)
        {
            var fb = await _repo.GetFeedbackByIdAsync(id);
            if (fb == null) return NotFound();
            return Ok(_mapper.Map<FeedbackDto>(fb));
        }

        // GET /api/feedbacks/ticket/{ticketId}
        [HttpGet("ticket/{ticketId:int}")]
        public async Task<ActionResult<IEnumerable<FeedbackDto>>> GetByTicket(int ticketId)
        {
            var feedbacks = await _repo.GetFeedbackByTicketId(ticketId);
            var dtos = feedbacks
                .Select(f => new FeedbackDto
                {
                    Id = f.Id,
                    TicketId = f.TicketId,
                    UserId = f.UserId,
                    Rating = f.Rating,
                    Comment = f.Comment,
                    CreatedAt = f.CreatedAt
                })
                .ToList();
            return Ok(dtos);
        }

        // POST /api/feedbacks
        [HttpPost]
        public async Task<ActionResult<FeedbackDto>> Create([FromBody] FeedbackCreateDto dto)
        {
            var entity = _mapper.Map<Feedback>(dto);
            var created = await _repo.CreateFeedback(entity);
            var outDto = _mapper.Map<FeedbackDto>(created);

            return CreatedAtAction(nameof(GetById),
                                   new { id = outDto.Id },
                                   outDto);
        }

        // PUT /api/feedbacks/{id}
        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, [FromBody] FeedbackUpdateDto dto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var existing = await _repo.GetFeedbackByIdAsync(id);
            if (existing == null) return NotFound();

            _mapper.Map(dto, existing);
            await _repo.UpdateFeedback(existing);
            return NoContent();
        }

        // DELETE /api/feedbacks/{id}
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var existing = await _repo.GetFeedbackByIdAsync(id);
            if (existing == null) return NotFound();

            await _repo.DeleteFeedback(id);
            return NoContent();
        }
    }
}
