﻿using HelpDesk.Core.DtoModels;
using HelpDesk.Core.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace HelpDesk.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HeatMapController : ControllerBase
    {
        private readonly IHeatMapService _heatMap;
        private readonly IUserRepository _users;
        private readonly IDepartmentRepository _depts;

        public HeatMapController(IHeatMapService heatMap, IUserRepository users, IDepartmentRepository depts)
        {
            _heatMap = heatMap;
            _users = users;
            _depts = depts;
        }

        [HttpGet("users/{userId:int}")]
        public async Task<IActionResult> GetUserHeatMap(int userId, [FromQuery] DateTime from, [FromQuery] DateTime to)
        {
            var user = await _users.GetUserById(userId);
            if (user == null)
                return NotFound($"User {userId} not found.");

            var dto = await _heatMap.GetUserHeatMap(userId, from, to);
            return Ok(dto);
        }

        [HttpGet("departments/{departmentId:int}")]
        public async Task<IActionResult> GetDepartmentHeatMap(int departmentId, [FromQuery] DateTime from, [FromQuery] DateTime to)
        {
            var dept = await _depts.GetDepartmentById(departmentId);
            if (dept == null)
                return NotFound($"Department {departmentId} not found.");

            var dto = await _heatMap.GetDepartmentHeatMap(departmentId, from, to);
            return Ok(dto);
        }
    }
}
