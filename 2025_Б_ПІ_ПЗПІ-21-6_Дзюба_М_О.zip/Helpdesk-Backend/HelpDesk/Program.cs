﻿using HelpDesk.Core.Interfaces;
using HelpDesk.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System;
using HelpDesk.Infrastructure.Models;
using HelpDesk.Core.Repositories;
using System.Text.Json.Serialization;
using HelpDesk.Core.Helper;
using AutoMapper;
using HelpDesk.Core.Helper;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Identity;
using HelpDesk.Core.Services;
using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using HelpDesk.Core.DtoModels;
using Microsoft.Extensions.ML;
using HelpDesk.AI.DataModels;

namespace HelpDesk
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            var jwt = builder.Configuration.GetSection("Jwt");
            var key = Encoding.UTF8.GetBytes(jwt["Key"]);

            // Add services to the container.
            builder.Services.AddAutoMapper(typeof(MappingProfile));

            builder.Services.AddCors(options =>
            {
                options.AddPolicy("HelpdeskCors", policy =>
                {
                    policy
                      .WithOrigins("http://localhost:5173")
                      .AllowAnyHeader()
                      .AllowAnyMethod()
                      .AllowCredentials();
                });
            });

            //builder.Services.AddControllers()
            builder.Services.AddControllers()
                .AddJsonOptions(opts => {
                    opts.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles;
                    opts.JsonSerializerOptions.WriteIndented = true;
                });


            builder.Services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(opts =>
            {
                opts.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidIssuer = jwt["Issuer"],
                    ValidateAudience = true,
                    ValidAudience = jwt["Audience"],
                    ValidateIssuerSigningKey = true,

                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    ValidateLifetime = true,
                    ClockSkew = TimeSpan.Zero
                };
            });
            builder.Services.AddScoped<IUserCompanyRepository, UserCompanyRepository>();
            builder.Services.AddScoped<IHeatMapService, HeatMapRepository>();
            builder.Services.AddScoped<HeatMapService>();
            builder.Services.AddScoped<ITicketRepository, TicketRepository>();
            builder.Services.AddScoped<IUserRepository, UserRepository>();
            builder.Services.AddScoped<ICompanyRepository, CompanyRepository>();
            builder.Services.AddScoped<IDepartmentRepository, DepartmentRepository>();
            builder.Services.AddScoped<IFeedbackRepository, FeedbackRepository>();
            builder.Services.AddScoped<ITicketClassificationRepository, TicketClassificationRepository>();
            builder.Services.AddScoped<ITicketRoutingRepository, TicketRoutingRepository>();
            builder.Services.AddScoped<IReportRepository, ReportRepository>();
            builder.Services.AddScoped<IdentificatorService>();
            builder.Services.AddScoped<IPasswordHasher<User>, PasswordHasher<User>>();
            builder.Services.AddSingleton<ITokenService, JwtTokenService>();
            builder.Services.AddScoped<ITicketRoutingService, TicketRoutingService>();
            builder.Services.AddScoped<IIncidentRepository, IncidentRepository>();
            builder.Services.AddScoped<IFeedbackRepository, FeedbackRepository>();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            builder.Services.AddDbContext<AppDbContext>(options =>
                options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")));

            builder.Services.AddPredictionEnginePool<ClassificationInput, ClassificationOutput>()
                .FromFile("CategoryModel", "CategoryModel.zip");

            builder.Services.AddPredictionEnginePool<ClassificationInput, ClassificationOutput>()
                .FromFile(
                    modelName: "PriorityModel",
                    filePath: "PriorityModel.zip",
                    watchForChanges: false);

            builder.Services.AddPredictionEnginePool<DeptData, DeptPrediction>()
                .FromFile(
                    modelName: "DeptEstimator",
                    filePath: "DeptEstimator.zip",
                    watchForChanges: false);

            builder.Services.AddPredictionEnginePool<UserData, UserPrediction>()
                .FromFile(
                    modelName: "UserEstimator",
                    filePath: "UserEstimator.zip",
                    watchForChanges: false);

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseCors("HelpdeskCors");
            app.UseHttpsRedirection();

            app.UseAuthentication();
            app.UseAuthorization();

            app.MapControllers();

            app.Run();
        }
    }
}