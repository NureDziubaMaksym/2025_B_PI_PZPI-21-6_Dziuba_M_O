﻿using Microsoft.ML.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDesk.AI.DataModels
{
    public class UserData
    {
        [LoadColumn(0)] public string Text;
        [LoadColumn(1)] public float OpenCount;
        [LoadColumn(2)] public float AvgResolution;
        [LoadColumn(3), ColumnName("Label")] public float LabelTime;
    }
}
