﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.ML.Data;

namespace HelpDesk.AI.DataModels
{
    public class ClassificationInput
    {
        [LoadColumn(0)]
        public string Title { get; set; }

        [LoadColumn(1)]
        public string Description { get; set; }

        [LoadColumn(2)]
        public string Category { get; set; }

        [LoadColumn(3)]
        public string Priority { get; set; }
    }
}
