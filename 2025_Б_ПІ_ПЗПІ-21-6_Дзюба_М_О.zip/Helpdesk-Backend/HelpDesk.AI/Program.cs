﻿using System;
using Microsoft.ML;
using HelpDesk.AI.DataModels;

namespace HelpDesk.AI
{
    class Program
    {
        private const string TicketsCsv = "TrainData/tickets.csv";
        private const string DeptCsv = "TrainData/dept_train.csv";
        private const string UserCsv = "TrainData/user_train.csv";
        private const string CategoryModel = "CategoryModel.zip";
        private const string PriorityModel = "PriorityModel.zip";
        private const string DeptEstimator = "DeptEstimator.zip";
        private const string UserEstimator = "UserEstimator.zip";

        static void Main(string[] args)
        {
            var mlContext = new MLContext(seed: 0);

            var data = mlContext.Data.LoadFromTextFile<ClassificationInput>(
                path: TicketsCsv, hasHeader: true, separatorChar: ',');

            var textPipeline = mlContext.Transforms.Text
                .FeaturizeText("TitleFeat", nameof(ClassificationInput.Title))
                .Append(mlContext.Transforms.Text
                    .FeaturizeText("DescFeat", nameof(ClassificationInput.Description)))
                .Append(mlContext.Transforms.Concatenate(
                    "Features", "TitleFeat", "DescFeat"));

            Console.WriteLine("Training Category classifier...");
            var catTrainer = textPipeline
                .Append(mlContext.Transforms.Conversion
                    .MapValueToKey("Label", nameof(ClassificationInput.Category)))
                .Append(mlContext.MulticlassClassification.Trainers
                    .SdcaMaximumEntropy("Label", "Features"))
                .Append(mlContext.Transforms.Conversion
                    .MapKeyToValue("PredictedLabel"));
            var catModel = catTrainer.Fit(data);
            mlContext.Model.Save(catModel, data.Schema, CategoryModel);

            Console.WriteLine("Training Priority classifier...");
            var prioTrainer = textPipeline
                .Append(mlContext.Transforms.Conversion
                    .MapValueToKey("Label", nameof(ClassificationInput.Priority)))
                .Append(mlContext.MulticlassClassification.Trainers
                    .SdcaMaximumEntropy("Label", "Features"))
                .Append(mlContext.Transforms.Conversion
                    .MapKeyToValue("PredictedLabel"));
            var prioModel = prioTrainer.Fit(data);
            mlContext.Model.Save(prioModel, data.Schema, PriorityModel);

            Console.WriteLine("Training Dept regression...");
            var deptData = mlContext.Data.LoadFromTextFile<DeptData>(
                DeptCsv, hasHeader: true, separatorChar: ',');
            var deptPipeline = mlContext.Transforms.Text
                .FeaturizeText("TextFeat", nameof(DeptData.Text))
                .Append(mlContext.Transforms.Concatenate(
                    "Features", "TextFeat",
                    nameof(DeptData.OpenCount),
                    nameof(DeptData.AvgResolution)))
                .Append(mlContext.Regression.Trainers
                    .Sdca(labelColumnName: "Label", featureColumnName: "Features"));
            var deptModel = deptPipeline.Fit(deptData);
            mlContext.Model.Save(deptModel, deptData.Schema, DeptEstimator);

            Console.WriteLine("Training User regression...");
            var userData = mlContext.Data.LoadFromTextFile<UserData>(
                UserCsv, hasHeader: true, separatorChar: ',');
            var userPipeline = mlContext.Transforms.Text
                .FeaturizeText("TextFeat", nameof(UserData.Text))
                .Append(mlContext.Transforms.Concatenate(
                    "Features", "TextFeat",
                    nameof(UserData.OpenCount),
                    nameof(UserData.AvgResolution)))
                .Append(mlContext.Regression.Trainers
                    .Sdca(labelColumnName: "Label", featureColumnName: "Features"));
            var userModel = userPipeline.Fit(userData);
            mlContext.Model.Save(userModel, userData.Schema, UserEstimator);

            Console.WriteLine("Done. Models saved:");
            Console.WriteLine($" - {CategoryModel} (9 classes)");
            Console.WriteLine($" - {PriorityModel} (3 classes)");
            Console.WriteLine($" - {DeptEstimator}");
            Console.WriteLine($" - {UserEstimator}");
        }
    }
}
