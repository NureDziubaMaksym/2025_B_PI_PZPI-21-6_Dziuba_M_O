﻿using HelpDesk.Core.Interfaces;
using HelpDesk.Core.Services;
using HelpDesk.Infrastructure.Data;
using HelpDesk.Infrastructure.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDesk.Core.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly AppDbContext _context;
        private readonly IdentificatorService _identificatorService;
        private readonly IPasswordHasher<User> _hasher;

        public UserRepository(AppDbContext context, IdentificatorService identificatorService, IPasswordHasher<User> hasher)
        {
            _context = context;
            _identificatorService = identificatorService;
            _hasher = hasher;
        }

        public async Task<User> GetUserById(int userId)
        {
            var output =  await _context.Users
                .AsNoTracking()
                .FirstOrDefaultAsync(u => u.Id == userId);
            
            if (output == null)
            {
                return null;
            }

            return output;
        }

        public async Task<IEnumerable<User>> GetAllUsers()
        {
            return await _context.Users.ToListAsync();
        }

        public async Task<User> CreateUser(User user, string plainPassword)
        {
            user.Id = await _identificatorService.GetNextIdAsync<User>(u => u.Id);

            user.CreatedAt = user.UpdatedAt = DateTime.UtcNow;
            user.PasswordHash = _hasher.HashPassword(user, plainPassword);

            await _context.Users.AddAsync(user);
            await _context.SaveChangesAsync();
            return user;
        }

        public async Task UpdateUser(User user)
        {
            user.UpdatedAt = DateTime.UtcNow;
            _context.Users.Update(user);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteUser(int userId)
        {
            var user = await _context.Users.FindAsync(userId);
            if (user != null)
            {
                _context.Users.Remove(user);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<User> GetUserByEmail(string email)
        {
            var output = await _context.Users
                .AsNoTracking()
                .FirstOrDefaultAsync(u => u.Email == email);

            if (output == null)
            {
                return null;
            }

            return output;
        }

        public async Task AssignToDepartmentAsync(int userId, int departmentId)
        {
            var user = await _context.Users.FindAsync(userId);
            if (user == null)
                throw new KeyNotFoundException($"User {userId} not found.");

            user.DepartmentId = departmentId;
            user.UpdatedAt = DateTime.UtcNow;

            _context.Users.Update(user);
            await _context.SaveChangesAsync();
        }

        public async Task<IEnumerable<User>> GetUsersWithoutDepartmentAsync()
        {
            return await _context.Users
                .Where(u => u.DepartmentId == null
                            && u.Role == UserRole.Specialist)
                .AsNoTracking()
                .ToListAsync();
        }

        public async Task UnassignDepartmentAsync(int userId)
        {
            var user = await _context.Users.FindAsync(userId);
            if (user == null)
                throw new KeyNotFoundException($"User {userId} not found.");

            user.DepartmentId = null;
            user.UpdatedAt = DateTime.UtcNow;

            _context.Users.Update(user);
            await _context.SaveChangesAsync();
        }
    }
}
