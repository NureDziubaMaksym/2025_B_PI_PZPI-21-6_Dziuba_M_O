﻿using HelpDesk.Core.Interfaces;
using HelpDesk.Infrastructure.Data;
using HelpDesk.Infrastructure.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDesk.Core.Repositories
{
    public class UserCompanyRepository : IUserCompanyRepository
    {
        private readonly AppDbContext _ctx;

        public UserCompanyRepository(AppDbContext ctx)
        {
            _ctx = ctx;
        }
        public async Task<IEnumerable<Company>> GetCompaniesByUser(int userId)
        {
            return await _ctx.UserCompanies
                .AsNoTracking()
                .Where(uc => uc.UserId == userId)
                .Select(uc => uc.Company)
                .ToListAsync();
        }
    }
}
