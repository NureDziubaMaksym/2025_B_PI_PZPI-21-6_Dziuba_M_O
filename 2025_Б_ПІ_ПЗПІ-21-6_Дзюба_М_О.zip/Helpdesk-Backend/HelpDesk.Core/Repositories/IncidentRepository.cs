﻿using HelpDesk.Core.Interfaces;
using HelpDesk.Core.Services;
using HelpDesk.Infrastructure.Data;
using HelpDesk.Infrastructure.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDesk.Core.Repositories
{
    public class IncidentRepository : IIncidentRepository
    {
        private readonly AppDbContext _ctx;
        private readonly IdentificatorService _idService;

        public IncidentRepository(AppDbContext ctx, IdentificatorService idService)
        {
            _ctx = ctx;
            _idService = idService;
        }

        public async Task<Incident> GetIncidentByIdAsync(int id) =>
            await _ctx.Incidents.FindAsync(id);

        public async Task<IEnumerable<Incident>> GetAllIncidentsAsync() =>
            await _ctx.Incidents.AsNoTracking().ToListAsync();

        public async Task<IEnumerable<Incident>> GetIncidentsByTicketIdAsync(int ticketId) =>
            await _ctx.Incidents
                      .AsNoTracking()
                      .Where(i => i.TicketId == ticketId)
                      .ToListAsync();

        public async Task<Incident> CreateIncidentAsync(Incident incident)
        {
            incident.Id = await _idService.GetNextIdAsync<Incident>(i => i.Id);
            await _ctx.Incidents.AddAsync(incident);
            await _ctx.SaveChangesAsync();
            return incident;
        }

        public async Task UpdateIncidentAsync(Incident incident)
        {
            _ctx.Incidents.Update(incident);
            await _ctx.SaveChangesAsync();
        }

        public async Task DeleteIncidentAsync(int id)
        {
            var ent = await _ctx.Incidents.FindAsync(id);
            if (ent != null)
            {
                _ctx.Incidents.Remove(ent);
                await _ctx.SaveChangesAsync();
            }
        }
    }
}
