﻿using HelpDesk.Core.Interfaces;
using HelpDesk.Core.Services;
using HelpDesk.Infrastructure.Data;
using HelpDesk.Infrastructure.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDesk.Core.Repositories
{
    public class TicketClassificationRepository : ITicketClassificationRepository
    {
        private readonly AppDbContext _ctx;
        private readonly IdentificatorService _identificatorService;

        public TicketClassificationRepository(AppDbContext ctx, IdentificatorService identificatorService)
        {
            _ctx = ctx;
            _identificatorService = identificatorService;
        }

        public async Task<TicketClassification> GetClassificationByTicketId(int ticketId)
        {
            var output =  await _ctx.TicketClassifications
                .FirstOrDefaultAsync(tc => tc.TicketId == ticketId);

            if (output == null)
            {
                throw new Exception($"there are no Classifications for id {ticketId}");
            }

            return output;
        }

        public async Task<IEnumerable<TicketClassification>> GetAllClassifications()
        {
            return await _ctx.TicketClassifications
                .AsNoTracking()
                .ToListAsync();
        }

        public async Task<TicketClassification> CreateTicketClassification(TicketClassification classification)
        {
            classification.ClassifiedAt = DateTime.UtcNow;
            classification.Id = await _identificatorService.GetNextIdAsync<TicketClassification>(c => c.Id);
            await _ctx.TicketClassifications.AddAsync(classification);
            await _ctx.SaveChangesAsync();
            return classification;
        }

        public async Task UpdateTicketClassification(TicketClassification classification)
        {
            _ctx.TicketClassifications.Update(classification);
            await _ctx.SaveChangesAsync();
        }

        public async Task DeleteTicketClassification(int classificationId)
        {
            var entity = await _ctx.TicketClassifications.FindAsync(classificationId);
            if (entity != null)
            {
                _ctx.TicketClassifications.Remove(entity);
                await _ctx.SaveChangesAsync();
            }
        }
    }
}
