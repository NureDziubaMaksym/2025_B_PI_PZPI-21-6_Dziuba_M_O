﻿using HelpDesk.Core.Interfaces;
using HelpDesk.Infrastructure.Data;
using HelpDesk.Infrastructure.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDesk.Core.Repositories
{
    public class ReportRepository : IReportRepository
    {
        private readonly AppDbContext _ctx;

        public ReportRepository(AppDbContext ctx)
        {
            _ctx = ctx;
        }

        public async Task<Report> GetReportsForUser(int userId)
        {
            var output = await _ctx.Reports
                .Include(r => r.User)
                .FirstOrDefaultAsync(r => r.UserId == userId);

            if (output == null)
            {
                throw new Exception($"There are no reports for user {userId}");
            }

            return output;
        }

        public async Task<Report> CreateReport(Report report)
        {
            report.CreatedAt = DateTime.UtcNow;
            await _ctx.Reports.AddAsync(report);
            await _ctx.SaveChangesAsync();
            return report;
        }

        public async Task UpdateReport(Report report)
        {
            _ctx.Reports.Update(report);
            await _ctx.SaveChangesAsync();
        }

        public async Task DeleteReport(int reportId)
        {
            var entity = await _ctx.Reports.FindAsync(reportId);
            if (entity != null)
            {
                _ctx.Reports.Remove(entity);
                await _ctx.SaveChangesAsync();
            }
        }

        public async Task ChangeReportType(int reportId, int newType)
        {
            var entity = await _ctx.Reports.FindAsync(reportId);
            if (entity != null)
            {
                entity.Type = (Report.ReportType)newType;
                _ctx.Reports.Update(entity);
                await _ctx.SaveChangesAsync();
            }
        }
    }
}
