﻿using HelpDesk.Core.Interfaces;
using HelpDesk.Core.Services;
using HelpDesk.Infrastructure.Data;
using HelpDesk.Infrastructure.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDesk.Core.Repositories
{
    public class FeedbackRepository : IFeedbackRepository
    {
        private readonly AppDbContext _appDbContext;
        private readonly IdentificatorService _idService;

        public FeedbackRepository(AppDbContext appDbContext, IdentificatorService idService)
        {
            _appDbContext = appDbContext;
            _idService = idService;
        }

        public async Task<List<Feedback>> GetFeedbackByTicketId(int ticketId)
        {
            return await _appDbContext.Feedback
                .Include(f => f.User)
                .Include(f => f.Ticket)
                .Where(f => f.TicketId == ticketId)
                .OrderBy(f => f.CreatedAt)   // опционально: сортировка по времени
                .ToListAsync();
        }

        public async Task<IEnumerable<Feedback>> GetAllFeedbacks()
        {
            return await _appDbContext.Feedback
                .Include(f => f.User)
                .Include(f => f.Ticket)
                .ToListAsync();
        }

        public async Task<Feedback> CreateFeedback(Feedback feedback)
        {
            feedback.Id = await _idService.GetNextIdAsync<Feedback>(f => f.Id);
            feedback.CreatedAt = DateTime.UtcNow;

            await _appDbContext.Feedback.AddAsync(feedback);
            await _appDbContext.SaveChangesAsync();
            return feedback;
        }

        public async Task UpdateFeedback(Feedback feedback)
        {
            _appDbContext.Feedback.Update(feedback);
            await _appDbContext.SaveChangesAsync();
        }

        public async Task DeleteFeedback(int feedbackId)
        {
            var entity = await _appDbContext.Feedback.FindAsync(feedbackId);
            if (entity != null)
            {
                _appDbContext.Feedback.Remove(entity);
                await _appDbContext.SaveChangesAsync();
            }
        }

        public async Task<Feedback> GetFeedbackByIdAsync(int id) =>
           await _appDbContext.Feedback.FindAsync(id);
    }
}
