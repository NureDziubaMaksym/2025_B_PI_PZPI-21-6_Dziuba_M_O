﻿using HelpDesk.Core.Interfaces;
using HelpDesk.Infrastructure.Data;
using HelpDesk.Infrastructure.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDesk.Core.Repositories
{
    public class CompanyRepository : ICompanyRepository
    {
        private readonly AppDbContext _ctx;

        public CompanyRepository(AppDbContext ctx)
        {
            _ctx = ctx;
        }

        public async Task<IEnumerable<Company>> GetCompanies()
        {
            return await _ctx.Companies
                .AsNoTracking()
                .ToListAsync();
        }

        public async Task<Company> GetCompanyById(int id)
        {
            var output = await _ctx.Companies
                .AsNoTracking()
                .FirstOrDefaultAsync(c => c.Id == id);
            
            if (output == null)
            {
                return null;
            }

            return output;
        }


        public async Task DeleteCompany(int id)
        {
            var entity = await _ctx.Companies.FindAsync(id);
            if (entity != null)
            {
                _ctx.Companies.Remove(entity);
                await _ctx.SaveChangesAsync();
            }
        }

        // PUT /api/companies/{id}
        public async Task UpdateCompany(Company company)
        {
            _ctx.Companies.Update(company);
            await _ctx.SaveChangesAsync();
        }

        public async Task<Company> CreateCompany(Company company)
        {
            await _ctx.Companies.AddAsync(company);
            await _ctx.SaveChangesAsync();
            return company;
        }
    }
}
