﻿using HelpDesk.Core.Interfaces;
using HelpDesk.Core.Services;
using HelpDesk.Infrastructure.Data;
using HelpDesk.Infrastructure.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDesk.Core.Repositories
{
    public class TicketRepository : ITicketRepository
    {
        private readonly AppDbContext _context;
        private readonly IdentificatorService _identificatorService;

        public TicketRepository(AppDbContext context, IdentificatorService identificatorService)
        {
            _context = context;
            _identificatorService = identificatorService;
        }

        public async Task<Ticket> GetTicketById(int ticketId)
        {
            var output = await _context.Tickets
                .AsNoTracking()
                .FirstOrDefaultAsync(t => t.Id == ticketId);

            if (output == null ) {
                return null;
            }

            return output;
        }


        public async Task<IEnumerable<Ticket>> GetAllTickets()
        {
            return await _context.Tickets
                .ToListAsync();
        }

        public async Task<IEnumerable<Ticket>> GetTicketsByUserId(int userId)
        {
            return await _context.Tickets
                .Where(t => t.TicketRouting
                .SelectMany(tr => tr.AssignedRoutings)
                .Any(ar => ar.UserId == userId))
                .Include(t => t.TicketRouting)
                .ThenInclude(tr => tr.AssignedRoutings)
                 .ThenInclude(ar => ar.User)
                .Include(t => t.TicketClassifications)
                .Include(t => t.Feedback)
                .ToListAsync();
        }

        public async Task<Ticket> CreateTicket(Ticket ticket)
        {
            ticket.UpdatedAt = ticket.CreatedAt = DateTime.UtcNow;
            ticket.Id = await _identificatorService.GetNextIdAsync<Ticket>(u => u.Id);

            await _context.Tickets.AddAsync(ticket);
            await _context.SaveChangesAsync();
            return ticket;
        }

        public async Task UpdateTicket(Ticket ticket)
        {
            _context.Tickets.Update(ticket);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteTicket(int ticketId)
        {
            var ticket = await _context.Tickets.FindAsync(ticketId);
            if (ticket != null)
            {
                _context.Tickets.Remove(ticket);
                await _context.SaveChangesAsync();
            }
        }
    }
}
