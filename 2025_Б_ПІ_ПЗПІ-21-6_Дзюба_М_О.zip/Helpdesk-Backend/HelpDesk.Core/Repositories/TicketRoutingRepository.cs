﻿using HelpDesk.Core.Interfaces;
using HelpDesk.Core.Services;
using HelpDesk.Infrastructure.Data;
using HelpDesk.Infrastructure.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HelpDesk.Core.Repositories
{
    public class TicketRoutingRepository : ITicketRoutingRepository
    {
        private readonly AppDbContext _ctx;
        private readonly IHeatMapService _heatMap;
        private readonly IdentificatorService _ids;

        public TicketRoutingRepository(AppDbContext ctx, IHeatMapService heatMap, IdentificatorService ids)
        {
            _ctx = ctx;
            _heatMap = heatMap;
            _ids = ids;
        }

        public async Task<TicketRouting> GetRoutingByTicketId(int ticketId)
        {
            return await _ctx.TicketRouting
                .Include(tr => tr.DepartmentRoutings)
                    .ThenInclude(dr => dr.Department)
                .Include(tr => tr.AssignedRoutings)
                    .ThenInclude(ar => ar.User)
                .FirstOrDefaultAsync(tr => tr.TicketId == ticketId);
        }

        public async Task<IEnumerable<TicketRouting>> GetRoutingsByUserId(int userId)
        {
            var routings = await _ctx.AssignedRoutings
                .Where(ar => ar.UserId == userId)
                .Select(ar => ar.TicketRouting)
                .Include(tr => tr.DepartmentRoutings)
                    .ThenInclude(dr => dr.Department)
                .Include(tr => tr.AssignedRoutings)
                    .ThenInclude(ar => ar.User)
                .ToListAsync();

            return routings;
        }

        public async Task<IEnumerable<TicketRouting>> GetAllTicketRoutings()
        {
            return await _ctx.TicketRouting
                .Include(tr => tr.DepartmentRoutings)
                    .ThenInclude(dr => dr.Department)
                .Include(tr => tr.AssignedRoutings)
                    .ThenInclude(ar => ar.User)
                .ToListAsync();
        }

        public async Task<TicketRouting> CreateTicketRouting(TicketRouting ticketRouting)
        {
            ticketRouting.Id = await _ids.GetNextIdAsync<TicketRouting>(r => r.Id);
            ticketRouting.RoutedAt = DateTime.UtcNow;
            ticketRouting.Status = RoutingStatus.Pending;
            await _ctx.TicketRouting.AddAsync(ticketRouting);
            await _ctx.SaveChangesAsync();
            return ticketRouting;
        }

        public async Task UpdateTicketRouting(TicketRouting ticketRouting)
        {
            _ctx.TicketRouting.Update(ticketRouting);
            await _ctx.SaveChangesAsync();
        }

        public async Task DeleteTicketRouting(int routingId)
        {
            var entity = await _ctx.TicketRouting.FindAsync(routingId);
            if (entity != null)
            {
                _ctx.TicketRouting.Remove(entity);
                await _ctx.SaveChangesAsync();
            }
        }

        public async Task ChangeRoutingStatus(int id, int newStatus)
        {
            var entity = await _ctx.TicketRouting.FindAsync(id);
            if (entity == null) return;
            entity.Status = (RoutingStatus)newStatus;
            await _ctx.SaveChangesAsync();
        }

        public async Task AssignToDepartment(int ticketId, int departmentId)
        {
            var route = await _ctx.TicketRouting
                .FirstOrDefaultAsync(r => r.TicketId == ticketId);
            if (route == null)
            {
                route = new TicketRouting
                {
                    TicketId = ticketId,
                    RoutedAt = DateTime.UtcNow,
                    Status = RoutingStatus.Pending
                };
                await _ctx.TicketRouting.AddAsync(route);
                await _ctx.SaveChangesAsync();
            }

            var dr = new DepartmentRouting
            {
                TicketRoutingId = route.Id,
                DepartmentId = departmentId
            };
            await _ctx.DepartmentRoutings.AddAsync(dr);
            await _ctx.SaveChangesAsync();

            await _heatMap.UpdateMetricsForTicket(ticketId, TicketEventType.AssignedToDepartment);
        }

        public async Task AssignToUser(int ticketId, int userId)
        {
            var route = await _ctx.TicketRouting
                .FirstOrDefaultAsync(r => r.TicketId == ticketId);
            if (route == null)
                throw new InvalidOperationException($"Routing for ticket {ticketId} not found.");

            var ar = new AssignedRouting
            {
                TicketRoutingId = route.Id,
                UserId = userId,
                AssignedAt = DateTime.UtcNow
            };
            await _ctx.AssignedRoutings.AddAsync(ar);
            await _ctx.SaveChangesAsync();

            await _heatMap.UpdateMetricsForTicket(ticketId, TicketEventType.AssignedToUser);
        }

        public async Task ChangeUserForTicket(int routingId, int newUserId)
        {
            var routing = await _ctx.TicketRouting
                .AsTracking()
                .FirstOrDefaultAsync(r => r.Id == routingId);
            if (routing == null)
                return;

            routing.RoutedAt = DateTime.UtcNow;
            _ctx.TicketRouting.Update(routing);

            var assignment = new AssignedRouting
            {
                TicketRoutingId = routingId,
                UserId = newUserId,
                AssignedAt = DateTime.UtcNow
            };
            await _ctx.AssignedRoutings.AddAsync(assignment);

            await _ctx.SaveChangesAsync();

            await _heatMap.UpdateMetricsForTicket(routing.TicketId, TicketEventType.AssignedToUser);
        }

        public async Task<IEnumerable<TicketRouting>> GetRoutingsByDepartmentAsync(int departmentId)
        {
            return await _ctx.TicketRouting
            .Include(tr => tr.Ticket)
            .Include(tr => tr.DepartmentRoutings)
            .ThenInclude(dr => dr.Department)
            .Include(tr => tr.AssignedRoutings)
            .ThenInclude(ar => ar.User)
            .Where(tr => tr.DepartmentRoutings
            .Any(dr => dr.DepartmentId == departmentId))
            .ToListAsync();
        }
    }
}



