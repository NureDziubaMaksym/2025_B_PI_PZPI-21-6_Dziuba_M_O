﻿using HelpDesk.Core.DtoModels;
using HelpDesk.Core.Interfaces;
using HelpDesk.Infrastructure.Data;
using HelpDesk.Infrastructure.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HelpDesk.Core.Repositories
{
    public class HeatMapRepository : IHeatMapService
    {
        private readonly AppDbContext _db;
        private const double SlaThresholdMinutes = 60.0;

        public HeatMapRepository(AppDbContext db)
        {
            _db = db;
        }

        public async Task<HeatMapDto> GetUserHeatMap(int userId, DateTime from, DateTime to)
        {
            var raw = await _db.HeatMapMetrics
                .Where(h => h.EntityType == "User"
                         && h.EntityId == userId
                         && h.MetricsDateTime >= from
                         && h.MetricsDateTime <= to)
                .OrderBy(h => h.MetricsDateTime)
                .ToListAsync();

            return new HeatMapDto
            {
                EntityId = userId,
                EntityType = "User",
                Points = raw
                    .Select(h => new HeatMapPointDto
                    {
                        Timestamp = h.MetricsDateTime,
                        OpenCount = h.OpenCount,
                        ClosedCount = h.ClosedCount,
                        AvgResolution = h.AvgResolution,
                        SlaViolations = h.SlaViolations
                    })
                    .ToList()
            };
        }

        public async Task<HeatMapDto> GetDepartmentHeatMap(int departmentId, DateTime from, DateTime to)
        {
            var raw = await _db.HeatMapMetrics
                .Where(h => h.EntityType == "Department"
                         && h.EntityId == departmentId
                         && h.MetricsDateTime >= from
                         && h.MetricsDateTime <= to)
                .OrderBy(h => h.MetricsDateTime)
                .ToListAsync();

            return new HeatMapDto
            {
                EntityId = departmentId,
                EntityType = "Department",
                Points = raw
                    .Select(h => new HeatMapPointDto
                    {
                        Timestamp = h.MetricsDateTime,
                        OpenCount = h.OpenCount,
                        ClosedCount = h.ClosedCount,
                        AvgResolution = h.AvgResolution,
                        SlaViolations = h.SlaViolations
                    })
                    .ToList()
            };
        }

        public async Task UpdateMetricsForTicket(int ticketId, TicketEventType eventType)
        {
            // 1) Загрузим тикет вместе со всеми маршрутами и назначениями
            var ticket = await _db.Tickets
                .Include(t => t.TicketRouting)
                    .ThenInclude(tr => tr.DepartmentRoutings)
                .Include(t => t.TicketRouting)
                    .ThenInclude(tr => tr.AssignedRoutings)
                .FirstOrDefaultAsync(t => t.Id == ticketId);

            if (ticket == null)
                throw new InvalidOperationException($"Ticket {ticketId} not found.");

            // Вспом. метод: обрезать до часа
            DateTime TruncateToHour(DateTime dt) =>
                new DateTime(dt.Year, dt.Month, dt.Day, dt.Hour, 0, 0, DateTimeKind.Utc);

            // 2) Решаем, какую метрику и когда обновлять
            DateTime snapshotTime = eventType switch
            {
                TicketEventType.Created =>
                    TruncateToHour(ticket.CreatedAt),

                TicketEventType.AssignedToDepartment =>
                TruncateToHour(
                    ticket.TicketRouting
                          .OrderByDescending(tr => tr.RoutedAt)
                          .FirstOrDefault()?.RoutedAt
                    ?? DateTime.UtcNow),

                TicketEventType.AssignedToUser =>
                TruncateToHour(
                    ticket.TicketRouting
                          .SelectMany(tr => tr.AssignedRoutings)
                          .OrderByDescending(ar => ar.AssignedAt)
                          .FirstOrDefault()?.AssignedAt
                    ?? DateTime.UtcNow),

                TicketEventType.Closed =>
                    TruncateToHour(DateTime.UtcNow),

                _ => TruncateToHour(DateTime.UtcNow)
            };

            // Вспом. локальный метод для получения или создания строки метрики
            async Task<HeatMapMetric> GetOrCreateMetricAsync(string type, int id)
            {
                var exist = await _db.HeatMapMetrics
                    .FirstOrDefaultAsync(h =>
                        h.EntityType == type &&
                        h.EntityId == id &&
                        h.MetricsDateTime == snapshotTime);

                if (exist != null) return exist;

                var metric = new HeatMapMetric
                {
                    EntityType = type,
                    EntityId = id,
                    MetricsDateTime = snapshotTime,
                    OpenCount = 0,
                    ClosedCount = 0,
                    AvgResolution = 0,
                    SlaViolations = 0
                };
                _db.HeatMapMetrics.Add(metric);
                await _db.SaveChangesAsync();
                return metric;
            }

            // 3) Логика для каждого события
            switch (eventType)
            {
                case TicketEventType.Created:
                    // 3.1) Для каждого департамента из первого маршрута +1 к OpenCount
                    var firstRoute = ticket.TicketRouting
                        .OrderBy(tr => tr.RoutedAt)
                        .FirstOrDefault();
                    if (firstRoute != null)
                    {
                        foreach (var dr in firstRoute.DepartmentRoutings)
                        {
                            var m = await GetOrCreateMetricAsync("Department", dr.DepartmentId);
                            m.OpenCount++;
                        }
                    }
                    break;

                case TicketEventType.AssignedToDepartment:
                    // 3.2) Для каждого департамента из последнего маршрута +1
                    var lastRoute = ticket.TicketRouting
                        .OrderByDescending(tr => tr.RoutedAt)
                        .FirstOrDefault();
                    if (lastRoute != null)
                    {
                        foreach (var dr in lastRoute.DepartmentRoutings)
                        {
                            var m = await GetOrCreateMetricAsync("Department", dr.DepartmentId);
                            m.OpenCount++;
                        }
                    }
                    break;

                case TicketEventType.AssignedToUser:
                    // 3.3) Для последнего назначенного специалиста +1
                    var lastAssign = ticket.TicketRouting
                        .SelectMany(tr => tr.AssignedRoutings)
                        .OrderByDescending(ar => ar.AssignedAt)
                        .FirstOrDefault();
                    if (lastAssign != null)
                    {
                        var m = await GetOrCreateMetricAsync("User", lastAssign.UserId);
                        m.OpenCount++;
                    }
                    break;

                case TicketEventType.Closed:
                    // 3.4) Закрытие: уменьшаем OpenCount, увеличиваем ClosedCount, пересчитываем AvgResolution и SLA
                    var closedTime = DateTime.UtcNow;
                    var resolutionMins = (closedTime - ticket.CreatedAt).TotalMinutes;

                    // Пользователь
                    var lastAssignee = ticket.TicketRouting
                        .SelectMany(tr => tr.AssignedRoutings)
                        .OrderByDescending(ar => ar.AssignedAt)
                        .FirstOrDefault();
                    if (lastAssignee != null)
                    {
                        var um = await GetOrCreateMetricAsync("User", lastAssignee.UserId);
                        if (um.OpenCount > 0) um.OpenCount--;
                        var oldClosed = um.ClosedCount;
                        var oldAvg = um.AvgResolution;
                        um.ClosedCount++;
                        um.AvgResolution = ((oldAvg * oldClosed) + resolutionMins) / um.ClosedCount;
                        if (resolutionMins > SlaThresholdMinutes) um.SlaViolations++;
                    }

                    // Департамент
                    var finalRoute = ticket.TicketRouting
                        .OrderByDescending(tr => tr.RoutedAt)
                        .FirstOrDefault();
                    if (finalRoute != null)
                    {
                        foreach (var dr in finalRoute.DepartmentRoutings)
                        {
                            var dm = await GetOrCreateMetricAsync("Department", dr.DepartmentId);
                            if (dm.OpenCount > 0) dm.OpenCount--;
                            var oldClosedD = dm.ClosedCount;
                            var oldAvgD = dm.AvgResolution;
                            dm.ClosedCount++;
                            dm.AvgResolution = ((oldAvgD * oldClosedD) + resolutionMins) / dm.ClosedCount;
                            if (resolutionMins > SlaThresholdMinutes) dm.SlaViolations++;
                        }
                    }
                    break;

                default:
                    throw new ArgumentOutOfRangeException(nameof(eventType), eventType, null);
            }

            // 4) Сохраняем все изменения за один раз
            await _db.SaveChangesAsync();
        }
    }
}
