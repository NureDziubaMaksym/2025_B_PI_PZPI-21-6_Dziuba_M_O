﻿using HelpDesk.Core.Interfaces;
using HelpDesk.Infrastructure.Data;
using HelpDesk.Infrastructure.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDesk.Core.Repositories
{
    public class DepartmentRepository : IDepartmentRepository
    {
        private readonly AppDbContext _appDbContext;

        public DepartmentRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public async Task<Department> GetDepartmentById(int departmentId)
        {
            var output =  await _appDbContext.Departments
                .FirstOrDefaultAsync(d => d.Id == departmentId);

            if (output == null)
            {
                return null;
            }

            return output;
        }

        public async Task<IEnumerable<Department>> GetAllDepartments()
        {
            return await _appDbContext.Departments
                .Include(d => d.Company)
                .ToListAsync();
        }

        public async Task<Department> CreateDepartment(Department department)
        {
            await _appDbContext.Departments.AddAsync(department);
            await _appDbContext.SaveChangesAsync();
            return department;
        }

        public async Task UpdateDepartment(Department department)
        {
            _appDbContext.Departments.Update(department);
            await _appDbContext.SaveChangesAsync();
        }

        public async Task DeleteDepartment(int departmentId)
        {
            var entity = await _appDbContext.Departments.FindAsync(departmentId);
            if (entity != null)
            {
                _appDbContext.Departments.Remove(entity);
                await _appDbContext.SaveChangesAsync();
            }
        }

        public async Task<IEnumerable<Department>> GetDepartmentsByCompany(int companyId)
        {
            return await _appDbContext.Departments
                .Where(d => d.CompanyId == companyId)
                .Include(d => d.Company)
                .ToListAsync();
        }

        public async Task<IEnumerable<User>> GetUsersByDepartment(int departmentId)
        {
            return await _appDbContext.Users
                .Where(u => u.DepartmentId == departmentId)
                .ToListAsync();
        }
    }
}
