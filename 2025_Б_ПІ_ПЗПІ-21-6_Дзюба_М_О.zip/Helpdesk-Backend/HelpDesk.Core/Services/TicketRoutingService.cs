﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HelpDesk.Core.DtoModels;
using HelpDesk.Core.Interfaces;
using HelpDesk.Infrastructure.Models;
using HelpDesk.AI.DataModels;
using Microsoft.Extensions.ML;
using Microsoft.ML;

namespace HelpDesk.Core.Services
{
    public class TicketRoutingService : ITicketRoutingService
    {
        private readonly PredictionEnginePool<ClassificationInput, ClassificationOutput> _categoryEngine;
        private readonly PredictionEnginePool<ClassificationInput, ClassificationOutput> _priorityEngine;
        private readonly PredictionEnginePool<DeptData, DeptPrediction> _deptEngine;
        private readonly PredictionEnginePool<UserData, UserPrediction> _userEngine;

        private readonly ITicketClassificationRepository _classificationRepo;
        private readonly ITicketRepository _ticketRepo;
        private readonly ITicketRoutingRepository _routingRepo;
        private readonly IDepartmentRepository _deptRepo;
        private readonly IUserRepository _userRepo;
        private readonly IHeatMapService _heatMap;

        private const double UserAdvantageMinutes = 5.0;

        public TicketRoutingService(
            PredictionEnginePool<ClassificationInput, ClassificationOutput> categoryEngine,
            PredictionEnginePool<ClassificationInput, ClassificationOutput> priorityEngine,
            PredictionEnginePool<DeptData, DeptPrediction> deptEngine,
            PredictionEnginePool<UserData, UserPrediction> userEngine,
            ITicketClassificationRepository classificationRepo,
            ITicketRepository ticketRepo,
            ITicketRoutingRepository routingRepo,
            IDepartmentRepository deptRepo,
            IUserRepository userRepo,
            IHeatMapService heatMap)
        {
            _categoryEngine = categoryEngine;
            _priorityEngine = priorityEngine;
            _deptEngine = deptEngine;
            _userEngine = userEngine;

            _classificationRepo = classificationRepo;
            _ticketRepo = ticketRepo;
            _routingRepo = routingRepo;
            _deptRepo = deptRepo;
            _userRepo = userRepo;
            _heatMap = heatMap;
        }

        public ClassificationResultDto Classify(TicketTextDto ticket)
        {
            var input = new ClassificationInput
            {
                Title = ticket.Title,
                Description = ticket.Description
            };

            var catOut = _categoryEngine.Predict<ClassificationInput, ClassificationOutput>("CategoryModel", input);
            var prioOut = _priorityEngine.Predict<ClassificationInput, ClassificationOutput>("PriorityModel", input);


            return new ClassificationResultDto
            {
                Category = catOut.PredictedLabel,
                Priority = prioOut.PredictedLabel,
                CategoryScores = catOut.Score,
                PriorityScores = prioOut.Score
            };
        }

        public async Task<RoutingDecisionDto> RouteAsync(TicketTextDto ticket)
        {
            var clf = Classify(ticket);
            await _classificationRepo.CreateTicketClassification(new Infrastructure.Models.TicketClassification
            {
                TicketId = ticket.Id,
                Category = clf.Category,
                Version = "v1.0",
                Confidence = (decimal)clf.CategoryScores.Max(),
                ClassifiedAt = DateTime.UtcNow
            });

            var tk = await _ticketRepo.GetTicketById(ticket.Id);
            tk.Priority = Enum.Parse<TicketPriority>(clf.Priority);
            await _ticketRepo.UpdateTicket(tk);

            var windowEnd = DateTime.UtcNow;
            var windowStart = windowEnd.AddHours(-1);

            var allDepts = await _deptRepo.GetAllDepartments();
            var deptEstimates = new List<(int deptId, double time)>();

            foreach (var d in allDepts)
            {
                var heat = await _heatMap.GetDepartmentHeatMap(d.Id, windowStart, windowEnd);
                var lastPoint = heat.Points.LastOrDefault() ?? new HeatMapPointDto();

                var dd = new DeptData
                {
                    Text = ticket.Title + " " + ticket.Description,
                    OpenCount = lastPoint.OpenCount,
                    AvgResolution = (float)lastPoint.AvgResolution,
                    LabelTime = 0f
                };

                var pred = _deptEngine.Predict<DeptData, DeptPrediction>("DeptEstimator", dd);
                deptEstimates.Add((d.Id, pred.EstimatedTime));
            }

            var (bestDeptId, bestDeptTime) = deptEstimates.OrderBy(x => x.time).First();

            var specialists = await _deptRepo.GetUsersByDepartment(bestDeptId);
            var userEstimates = new List<(int userId, double time)>();

            foreach (var u in specialists)
            {
                var heatU = await _heatMap.GetUserHeatMap(u.Id, windowStart, windowEnd);
                var lp = heatU.Points.LastOrDefault() ?? new HeatMapPointDto();

                var ud = new UserData
                {
                    Text = ticket.Title + " " + ticket.Description,
                    OpenCount = lp.OpenCount,
                    AvgResolution = (float)lp.AvgResolution,
                    LabelTime = 0f
                };

                var predU = _userEngine.Predict<UserData, UserPrediction>("UserEstimator", ud);
                userEstimates.Add((u.Id, predU.EstimatedTime));
            }

            if (userEstimates.Any())
            {
                var (bestUserId, bestUserTime) = userEstimates.OrderBy(x => x.time).First();
                if (bestUserTime + UserAdvantageMinutes < bestDeptTime)
                {
                    await _routingRepo.AssignToUser(ticket.Id, bestUserId);
                    return new RoutingDecisionDto
                    {
                        AssignedUserId = bestUserId,
                        EstimatedTime = bestUserTime
                    };
                }
            }

            await _routingRepo.AssignToDepartment(ticket.Id, bestDeptId);
            return new RoutingDecisionDto
            {
                AssignedDepartmentId = bestDeptId,
                EstimatedTime = bestDeptTime
            };
        }
    }
}
