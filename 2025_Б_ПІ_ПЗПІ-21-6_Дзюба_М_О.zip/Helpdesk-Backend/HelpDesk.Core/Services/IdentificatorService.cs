﻿using HelpDesk.Infrastructure.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace HelpDesk.Core.Services
{
    public class IdentificatorService
    {
        private readonly AppDbContext _ctx;

        public IdentificatorService(AppDbContext ctx)
        {
            _ctx = ctx;
        }

        public async Task<int> GetNextIdAsync<TEntity>(Expression<Func<TEntity, int>> idSelector)
            where TEntity : class
        {
            var set = _ctx.Set<TEntity>();
            var max = await set.AnyAsync()
                ? await set.MaxAsync(idSelector)
                : 0;
            return max + 1;
        }
    }
}
