﻿using HelpDesk.Core.DtoModels;
using HelpDesk.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDesk.Core.Services
{
    public class HeatMapService : IHeatMapService
    {
        private readonly IHeatMapService _repo;

        public HeatMapService(IHeatMapService repo)
        {
            _repo = repo;
        }

        public Task<HeatMapDto> GetUserHeatMap(int userId, DateTime from, DateTime to)
        {
            return _repo.GetUserHeatMap(userId, from, to);
        }

        public Task<HeatMapDto> GetDepartmentHeatMap(int departmentId, DateTime from, DateTime to)
        {
            return _repo.GetDepartmentHeatMap(departmentId, from, to);
        }

        public Task UpdateMetricsForTicket(int ticketId, TicketEventType eventType)
        {
            return _repo.UpdateMetricsForTicket(ticketId, eventType);
        }
    }
}
