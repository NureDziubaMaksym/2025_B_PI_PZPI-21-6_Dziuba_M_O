﻿using AutoMapper;
using HelpDesk.Core.DtoModels;
using HelpDesk.Infrastructure.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDesk.Core.Helper
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<User, UserDto>()
                .ForMember(d => d.Role, opt => opt.MapFrom(s => s.Role.ToString()));

            CreateMap<UserCreateDto, User>()
                .ForMember(d => d.PasswordHash,
                           opt => opt.MapFrom(s => s.Password))
                .ForMember(d => d.Role,
                           opt => opt.MapFrom(s => Enum.Parse<UserRole>(s.Role)))
                .ForMember(d => d.CreatedAt, opt => opt.Ignore())
                .ForMember(d => d.UpdatedAt, opt => opt.Ignore());

            CreateMap<UserUpdateDto, User>()
                .ForMember(d => d.Role,
                           opt => opt.MapFrom(s => Enum.Parse<UserRole>(s.Role)))
                .ForMember(d => d.UpdatedAt, opt => opt.Ignore())
                .ForAllMembers(opt => opt.Condition((src, dest, srcMember) => srcMember != null));

            CreateMap<Ticket, TicketDto>()
                .ForMember(d => d.Priority, opt => opt.MapFrom(s => s.Priority.ToString()))
                .ForMember(d => d.Status, opt => opt.MapFrom(s => s.Status.ToString()));

            CreateMap<TicketCreateDto, Ticket>()
                .ForMember(d => d.Id, opt => opt.Ignore())
                .ForMember(d => d.Status, opt => opt.MapFrom(s => TicketStatus.Open))
                .ForMember(d => d.CreatedAt, opt => opt.Ignore())
                .ForMember(d => d.UpdatedAt, opt => opt.Ignore());

            CreateMap<TicketUpdateDto, Ticket>()
                .ForMember(d => d.Id, opt => opt.Ignore())
                .ForMember(d => d.CreatedAt, opt => opt.Ignore())
                .ForMember(d => d.UpdatedAt, opt => opt.Ignore())
                .ForMember(d => d.Status,
                    opt => opt.MapFrom(s => Enum.Parse<TicketStatus>(s.Status)))
                .ForMember(d => d.Priority,
                    opt => opt.MapFrom(s => Enum.Parse<TicketPriority>(s.Priority)))
                .ForAllMembers(opt =>
                    opt.Condition((src, dest, srcMember) => srcMember != null));

            CreateMap<TicketClassification, TicketClassificationDto>();

            CreateMap<TicketClassificationCreateDto, TicketClassification>()
                .ForMember(dest => dest.ClassifiedAt, opt => opt.MapFrom(_ => DateTime.UtcNow));

            CreateMap<TicketClassificationUpdateDto, TicketClassification>()
                .ForMember(dest => dest.ClassifiedAt, opt => opt.Ignore());

            CreateMap<Company, CompanyDto>();

            CreateMap<CompanyCreateDto, Company>()
            .ForMember(dest => dest.Id, opt => opt.Ignore())
            .ForMember(dest => dest.Departments, opt => opt.Ignore());

            CreateMap<Department, DepartmentDto>();

            CreateMap<DepartmentCreateDto, Department>()
                .ForMember(d => d.Id, opt => opt.Ignore())
                .ForMember(d => d.DepartmentRoutings, opt => opt.Ignore())
                .ForMember(d => d.Users, opt => opt.Ignore())
                .ForMember(d => d.TicketRoutings, opt => opt.Ignore());

            CreateMap<TicketRouting, TicketRoutingDto>()
            .ForMember(d => d.Status, opt =>
                opt.MapFrom(s => s.Status.ToString()));

            CreateMap<TicketRoutingCreateDto, TicketRouting>()
                .ForMember(d => d.Id, opt => opt.Ignore())
                .ForMember(d => d.RoutedAt, opt => opt.Ignore())
                .ForMember(d => d.Ticket, opt => opt.Ignore())
                .ForMember(d => d.DepartmentRoutings, opt => opt.Ignore())
                .ForMember(d => d.AssignedRoutings, opt => opt.Ignore())
                .ForMember(d => d.Status, opt =>
                    opt.MapFrom(s => Enum.Parse<RoutingStatus>(s.Status)));

            CreateMap<Incident, IncidentDto>();

            CreateMap<IncidentCreateDto, Incident>();

            CreateMap<IncidentUpdateDto, Incident>()
                .ForMember(dest => dest.Id, opt => opt.Ignore())
                .ForMember(dest => dest.UserId, opt => opt.Ignore())
                .ForMember(dest => dest.TicketId, opt => opt.Ignore());

            CreateMap<Feedback, FeedbackDto>();

            CreateMap<FeedbackCreateDto, Feedback>()
                .ForMember(dest => dest.Id, opt => opt.Ignore())
                .ForMember(dest => dest.CreatedAt, opt => opt.Ignore());

            CreateMap<FeedbackUpdateDto, Feedback>()
                .ForMember(dest => dest.Id, opt => opt.Ignore())
                .ForMember(dest => dest.TicketId, opt => opt.Ignore())
                .ForMember(dest => dest.UserId, opt => opt.Ignore())
                .ForMember(dest => dest.CreatedAt, opt => opt.Ignore());

        }
    }
}
