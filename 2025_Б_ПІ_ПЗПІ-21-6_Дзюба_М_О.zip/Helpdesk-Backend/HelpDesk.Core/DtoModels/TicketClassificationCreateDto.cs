﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDesk.Core.DtoModels
{
    public class TicketClassificationCreateDto
    {
        public int TicketId { get; set; }
        public string Category { get; set; } = null!;
        public string Version { get; set; } = null!;
        public decimal Confidence { get; set; }
    }
}
