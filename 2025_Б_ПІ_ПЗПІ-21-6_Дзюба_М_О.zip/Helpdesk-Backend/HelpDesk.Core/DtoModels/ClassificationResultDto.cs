﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDesk.Core.DtoModels
{
    public class ClassificationResultDto
    {
        public string Category { get; set; }
        public string Priority { get; set; }
        public float[] CategoryScores { get; set; }
        public float[] PriorityScores { get; set; }
    }
}
