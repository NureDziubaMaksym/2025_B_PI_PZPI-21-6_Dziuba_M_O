﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDesk.Core.DtoModels
{
    public class HeatMapPointDto
    {
        public DateTime Timestamp { get; set; }


        public int OpenCount { get; set; }

        public int ClosedCount { get; set; }

        public double AvgResolution { get; set; }

        public int SlaViolations { get; set; }
    }
}
