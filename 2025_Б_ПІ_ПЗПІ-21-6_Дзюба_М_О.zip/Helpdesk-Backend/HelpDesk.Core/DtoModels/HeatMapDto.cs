﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDesk.Core.DtoModels
{
    public class HeatMapDto
    {
        public int EntityId { get; set; }

        public string EntityType { get; set; }

        public List<HeatMapPointDto> Points { get; set; } = new List<HeatMapPointDto>();
    }
}
