﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDesk.Core.DtoModels
{
    public class RoutingDecisionDto
    {
        public int? AssignedDepartmentId { get; set; }
        public int? AssignedUserId { get; set; }
        public double EstimatedTime { get; set; }
    }
}
