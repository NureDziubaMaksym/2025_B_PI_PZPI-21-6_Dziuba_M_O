﻿using HelpDesk.Infrastructure.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDesk.Core.Interfaces
{
    public interface ITicketClassificationRepository
    {
        Task<TicketClassification> GetClassificationByTicketId(int ticketId);
        Task<IEnumerable<TicketClassification>> GetAllClassifications();
        Task<TicketClassification> CreateTicketClassification(TicketClassification classification);
        Task UpdateTicketClassification(TicketClassification classification);
        Task DeleteTicketClassification(int classificationId);
    }
}
