﻿using HelpDesk.Infrastructure.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDesk.Core.Interfaces
{
    public interface IDepartmentRepository
    {
        Task<Department> GetDepartmentById(int departmentId);
        Task<IEnumerable<Department>> GetAllDepartments();
        Task<Department> CreateDepartment(Department department);
        Task UpdateDepartment(Department department);
        Task DeleteDepartment(int departmentId);
        Task<IEnumerable<Department>> GetDepartmentsByCompany(int companyId);
        Task<IEnumerable<User>> GetUsersByDepartment(int departmentId);
    }
}
