﻿using HelpDesk.Core.DtoModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDesk.Core.Interfaces
{
    public interface ITicketRoutingService
    {
        ClassificationResultDto Classify(TicketTextDto ticket);
        Task<RoutingDecisionDto> RouteAsync(TicketTextDto ticket);
    }
}
