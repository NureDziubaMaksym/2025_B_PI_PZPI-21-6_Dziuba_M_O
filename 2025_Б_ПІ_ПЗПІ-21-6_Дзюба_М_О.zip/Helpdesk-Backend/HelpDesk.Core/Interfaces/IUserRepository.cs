﻿using HelpDesk.Infrastructure.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDesk.Core.Interfaces
{
    public interface IUserRepository
    {
        Task<User> GetUserById(int userId);
        Task<IEnumerable<User>> GetAllUsers();
        Task<User> CreateUser(User user, string plainPassword);
        Task UpdateUser(User user);
        Task DeleteUser(int userId);
        Task<User> GetUserByEmail(string email);
        Task AssignToDepartmentAsync(int userId, int departmentId);
        Task<IEnumerable<User>> GetUsersWithoutDepartmentAsync();
        Task UnassignDepartmentAsync(int userId);
    }
}
