﻿using HelpDesk.Infrastructure.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDesk.Core.Interfaces
{
    public interface ICompanyRepository
    {
        Task<IEnumerable<Company>> GetCompanies();
        Task<Company> GetCompanyById(int id);
        Task DeleteCompany(int id);
        Task UpdateCompany(Company company);
        Task<Company> CreateCompany(Company company);
    }
}
