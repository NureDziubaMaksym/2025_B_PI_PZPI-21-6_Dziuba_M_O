﻿using HelpDesk.Core.DtoModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDesk.Core.Interfaces
{
    public enum TicketEventType
    {
        Created,
        AssignedToUser,
        AssignedToDepartment,
        Closed
    }

    public interface IHeatMapService
    {
        Task<HeatMapDto> GetUserHeatMap(int userId, DateTime from, DateTime to);
        Task<HeatMapDto> GetDepartmentHeatMap(int departmentId, DateTime from, DateTime to);
        Task UpdateMetricsForTicket(int ticketId, TicketEventType eventType);
    }
}
