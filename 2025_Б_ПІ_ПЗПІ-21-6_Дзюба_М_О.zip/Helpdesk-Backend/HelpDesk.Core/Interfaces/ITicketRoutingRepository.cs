﻿using HelpDesk.Infrastructure.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDesk.Core.Interfaces
{
    public interface ITicketRoutingRepository
    {
        Task<TicketRouting> GetRoutingByTicketId(int ticketId);
        Task<IEnumerable<TicketRouting>> GetRoutingsByUserId(int userId);
        Task<IEnumerable<TicketRouting>> GetAllTicketRoutings();
        Task<TicketRouting> CreateTicketRouting(TicketRouting ticketRouting);
        Task UpdateTicketRouting(TicketRouting ticketRouting);
        Task DeleteTicketRouting(int routingId);
        Task ChangeRoutingStatus(int id, int newStatus);
        Task ChangeUserForTicket(int id, int newUserId); //changes the UserId(it means to change who is working with ticket)

        Task AssignToDepartment(int ticketId, int departmentId);
        Task AssignToUser(int ticketId, int userId);
        Task<IEnumerable<TicketRouting>> GetRoutingsByDepartmentAsync(int departmentId);
    }
}
