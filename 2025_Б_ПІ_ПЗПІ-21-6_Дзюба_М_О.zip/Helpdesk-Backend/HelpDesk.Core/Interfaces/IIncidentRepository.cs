﻿using HelpDesk.Infrastructure.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelpDesk.Core.Interfaces
{
    public interface IIncidentRepository
    {
        Task<Incident> GetIncidentByIdAsync(int id);
        Task<IEnumerable<Incident>> GetAllIncidentsAsync();
        Task<IEnumerable<Incident>> GetIncidentsByTicketIdAsync(int ticketId);
        Task<Incident> CreateIncidentAsync(Incident incident);
        Task UpdateIncidentAsync(Incident incident);
        Task DeleteIncidentAsync(int id);
    }
}
